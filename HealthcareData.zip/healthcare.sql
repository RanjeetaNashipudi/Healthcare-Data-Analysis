//1. Fetch the details of the patient who are above age greater than 85 and are suffering from Asthama//
select * from healthcare_tb
where age>=85 and medical_condition='Asthma'
order by name asc;

//2.//Count_the_total_number_of_male_&_female_patients suffering_from_diabetes//
select gender,count(*),medical_condition from healthcare_tb
where medical_condition='Diabetes'
group by medical_condition,gender
order by gender asc;

//3. fetch_the_name_of_the_doctor_who_has_treated for cancer medicalcondition//
select Name,doctor,medical_condition as Diesease from healthcare_tb
where medical_condition='Cancer'
order by name asc;

//4.count_the_distinct_insurance_providers_name along with total number of insurances provided by them order by highest_number/
select distinct(insurance_provider),(count(insurance_provider))as Total_insurance_provided from healthcare_tb
group by insurance_provider
order by count(insurance_provider) desc;

//5.list the number of patients who are admitted for more than or equal to 1 month//
select P_id,name,(discharge_date-date_of_admission) as total_admitted_days from healthcare_tb
where (discharge_date-date_of_admission>=30);



//6.list out the patients name who have 'o'negative blood group//
select name,blood_type from healthcare_tb
where blood_type='O-'

//7. listout the totalnumber of hospitalname who have treated cancer diseases//
with cancerhospital as
(
select distinct(hospital) from healthcare_tb
where medical_condition='Cancer'
order by hospital asc)
select count(hospital) as Total_cancer_hospitals from cancerhospital;

//8.count the number of diabetes ,asthama,obesity,hypertension and cancer patient details
with total_number_of_patients as(
select name,medical_condition from healthcare_tb
where medical_condition in ('Diabetes','Asthma','Obesity','Hypertension','Cancer','Arthritis')
order by medical_condition
)
select medical_condition,count(medical_condition)as total_no from total_number_of_patients

group by medical_condition
order by count(medical_condition)desc;

//9.list out the arthritis patients who have admitted between the year 2020 to 2022

select name,medical_condition,date_of_admission from healthcare_tb
where date_of_admission between to_date( '01-01-2020', 'dd-mm-yyyy' )
and to_date( '31-12-2022', 'dd-mm-yyyy' ) and medical_condition='Arthritis'
order by date_of_admission asc;

//10.Details of 5 highest paid billing amount by  insurance providers//

select distinct(insurance_provider),billing_amount from healthcare_tb
order by billing_amount desc
fetch first 5 rows only;

//11. fetch the diseases name where females are more in number//


select medical_condition,gender,count(*)as total_number from healthcare_tb
group by gender,medical_condition
order by medical_condition

//12. list the medications used to treat Arthritis//

select distinct(medication) from healthcare_tb
where medical_condition='Arthritis'

